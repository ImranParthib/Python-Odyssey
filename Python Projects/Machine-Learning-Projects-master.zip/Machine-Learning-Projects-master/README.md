# MACHINE LEARNING DEVELOPMENT PROJECTS

These projects were accomplished in cooperation with Udemy course:
  - Python 3 Programming: "Begginer to Pro MasterClass"
  - Python A-Z: "Python For Data Science With Real Exercises!"
  - Python for Data Science and Machine Learning Bootcamp
  - Machine Learning A-Z™: Hands-On Python & R In Data Science
  - Deep Learning and NLP A-Z™: How to create a ChatBot
  - Deep Learning A-Z™: Hands-On Artificial Neural Networks
  - Artificial Intelligence A-Z™: Learn How To Build An AI

Install Anaconda Python 3.6 version
  - https://conda.io/docs/user-guide/install/index.html 
  
Install Python 3.6
  - https://www.python.org/downloads/release/python-360/
  
Install Jupyter Notebook
  - https://jupyter.org/install
  
Install Spider
  - https://www.spyder-ide.org/



